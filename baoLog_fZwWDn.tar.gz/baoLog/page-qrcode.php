<?php
/**
Template Name: 在线生成二维码
 **/
get_header(); ?>

    <body mpa-version="7.16.12" mpa-extension-id="aidjohbjielfdhcaookdaolppglahebo" data-new-gr-c-s-check-loaded="14.990.0"
          data-gr-ext-installed="">
<!--header-->
<main id="body">
    <div class="container">
        <div class="divider"></div>

        <div class="post-body">
            <!--首页导航 需要自己添加进去-->

            <!--内容-->
            <h2>正在开发中...</h2>

        </div>

    </div>
</main>

<!-- sidebar -->
<?php
get_sidebar();
?>
<!--footer-->
<?php get_footer(); ?>